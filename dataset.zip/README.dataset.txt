# EpicureAi > 2023-11-28 4:58pm
https://universe.roboflow.com/wagon/epicureai

Provided by a Roboflow user
License: CC BY 4.0

